package lt.bit.draudimas.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import lt.bit.draudimas.entities.Owner;

public interface OwnerRepository extends JpaRepository<Owner, Integer> {
	
	
	List<Owner> findByUserId(Integer userId);
	
	

}
