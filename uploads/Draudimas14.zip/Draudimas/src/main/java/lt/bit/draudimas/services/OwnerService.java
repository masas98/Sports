package lt.bit.draudimas.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import lt.bit.draudimas.entities.Owner;
import lt.bit.draudimas.entities.User;
import lt.bit.draudimas.repositories.OwnerRepository;

@Service
public class OwnerService {
	
	@Autowired
	OwnerRepository ownerRepository;
	
	public List<Owner> getOwners(){
		return ownerRepository.findAll();
	}
	
	public Owner addOwner(Owner owner) {
		return ownerRepository.save(owner);
	}
	
	public Owner getOwnerById(Integer id) {
		return ownerRepository.findById(id).orElse(null);
	}
	
	public Owner updateOwner(Owner owner) {
		Owner old=this.getOwnerById(owner.getId());
		old.setName(owner.getName());
		old.setSurname(owner.getSurname());
		old.setEmail(owner.getEmail());
		old.setPhone(owner.getPhone());
		old.setBirthDate(owner.getBirthDate());
		old.setUser(owner.getUser());
		old.setCarNumber(owner.getCarNumber());
		ownerRepository.save(old);
		return old;
	}
	
	public void deleteOwner(Integer id) {
		ownerRepository.deleteById(id);
	}
	
	public List<Owner> getMyOwners(){
		Authentication auth=SecurityContextHolder.getContext().getAuthentication();
		if (auth==null) return null;
		User secUser=(User)auth.getPrincipal();
		return ownerRepository.findByUserId(secUser.getId());
	}
	

}
