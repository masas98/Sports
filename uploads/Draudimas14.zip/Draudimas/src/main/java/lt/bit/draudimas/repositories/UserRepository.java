package lt.bit.draudimas.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import lt.bit.draudimas.classes.IOwnersCount;
import lt.bit.draudimas.classes.OwnersCount;
import lt.bit.draudimas.entities.User;

public interface UserRepository extends JpaRepository<User, Integer>{
	User findByUsername(String username);
	User findByEmail(String email);
	/*
	 * 
	   SELECT new lt.bit.draudimas.classes.OwnersCount(u.id, u.username, count(*)) FROM User u LEFT JOIN Owner o ON u.id=o.user_id GROUP BY u.id
       SELECT new lt.bit.draudimas.classes.OwnersCount(u.id, u.username, count(*)) FROM User u LEFT JOIN u.owner o LEFT o.insurance  GROUP BY u
	 * 
	 */
	@Query("SELECT new lt.bit.draudimas.classes.OwnersCount(u.id, u.username, count(*)) FROM User u LEFT JOIN u.owner GROUP BY u")
	List<OwnersCount> countOwners();
	
	@Query("SELECT u.id as id, u.username as username, count(*) as owners FROM User u LEFT JOIN u.owner GROUP BY u")
	List<IOwnersCount> countOwnersI();
	

}
