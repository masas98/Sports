package lt.bit.draudimas.entities;


import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

import lt.bit.draudimas.constrains.CarNumber;

@Entity
@Table(name = "owners")
public class Owner {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column
	@NotEmpty(message = "Vardas yra privalomas")
	@Size(min=3, max=16, message = "Vardas turi būti ne trumpesnis nei 3 simboliai ir ne ilgesnis nei 16 simbolių")
	private String name;

	@Column
	@NotEmpty(message = "Pavardė yra privaloma")
	@Size(min=3, max=16, message = "Pavardė turi būti ne trumpesnė nei 3 simboliai ir ne ilgesnė nei 16 simbolių")
	private String surname;
	
	@Column
	@Email(message = "Įveskite teisingą el. pašto adresą")
	private String email;
	
	@Column
	private String phone;
	
	@Column
	private String address;
	
	@Column(name = "car_number")
	@CarNumber
	private String carNumber;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	@Column(name = "birth_date", nullable = true)
	private Date birthDate;
	
	@OneToMany( mappedBy = "owner", fetch = FetchType.EAGER )
	private List<Insurance> insurances;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	
	@Column(insertable=false, updatable = false)
	private Integer user_id;

	public Owner() {
		
	}

	public Owner(String name, String surname, String email, String phone, String address) {
	
		this.name = name;
		this.surname = surname;
		this.email = email;
		this.phone = phone;
		this.address = address;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public List<Insurance> getInsurances() {
		return insurances;
	}

	public void setInsurances(List<Insurance> insurances) {
		this.insurances = insurances;
	}
	
	

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String toString() {
		return this.name;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	
	
	

}
