package lt.bit.draudimas.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import lt.bit.draudimas.classes.IOwnersCount;
import lt.bit.draudimas.classes.OwnersCount;
import lt.bit.draudimas.entities.Owner;
import lt.bit.draudimas.entities.User;
import lt.bit.draudimas.repositories.UserRepository;

@Service
public class UserService implements UserDetailsService{
	
	@Autowired
	private UserRepository userRepository;
	
	public User findByUsername(String username) {
		return userRepository.findByUsername(username);
	}
	
	public User findByEmail(String email) {
		return userRepository.findByEmail(email);
	}
	
	public User addUser(User user) {
		user.setPassword( (new BCryptPasswordEncoder()).encode(user.getPassword()));
		return userRepository.save(user);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user=userRepository.findByUsername(username);
		if (user==null) {
			throw new UsernameNotFoundException("Vartotojas nerastas");
		}
		
		return user;
	}

	public List<User> getUsers() {
		return userRepository.findAll();
	}
	
	public User getUserById(Integer id) {
		return userRepository.findById(id).orElse(null);
	}
	
	public List<OwnersCount> countOwners(){
		return userRepository.countOwners();
	}
	
	public List<IOwnersCount> countOwnersI(){
		return userRepository.countOwnersI();
	}

}
