package lt.bit.draudimas.constrains;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CarNumberValidator implements ConstraintValidator<CarNumber, String> {

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (value==null) return true;
		return value.matches("[a-zA-Z]{3}[0-9]{3}");
	}

}
