package lt.bit.draudimas.controller;

import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import lt.bit.draudimas.entities.Insurance;
import lt.bit.draudimas.entities.Owner;
import lt.bit.draudimas.repositories.OwnerRepository;
import lt.bit.draudimas.services.OwnerService;
import lt.bit.draudimas.services.UserService;


@Controller
@RequestMapping("/owners")
public class OwnerController {

	@Autowired
	OwnerService ownerService;
	
	@Autowired
	UserService userService;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}
	
	@GetMapping("/")
	public String owners(Model model, Authentication auth) {
		
		model.addAttribute("ownerId", 2);
		
		boolean admin=false;
		for (GrantedAuthority ga:auth.getAuthorities()) {
		   if (ga.getAuthority().equals("admin")) {
			   admin=true;
			   break;
		   }
		}
		
		if(admin) {
			
			model.addAttribute("owners",  ownerService.getOwners());
		}else {
			model.addAttribute("owners", ownerService.getMyOwners());
		}
		
		return "owners";
	}
	
	@GetMapping("/new")
	public String newOwner(Model model) {
		model.addAttribute("owner", new Owner());
		model.addAttribute("users", userService.getUsers());
		return "owner_new";
	}
	
	@PostMapping("/new")
	public String saveOwner(
			@Valid 
			@ModelAttribute 
			Owner owner, 
			BindingResult result,
			
			@RequestParam("userId") 
			Integer userId,
			
			Model model
			) {
		
		
		owner.setUser(userService.getUserById(userId));
		
		if (result.hasErrors()) {
			return "owner_new";
		}
		
		ownerService.addOwner(owner);
		return "redirect:/owners/";
	}
	
	@GetMapping("/update")
	public String showOwner(@RequestParam("id") Integer id, Model model) {
		model.addAttribute("owner", ownerService.getOwnerById(id));
		model.addAttribute("users", userService.getUsers());
		return "owner_update";
	}
	
	@PostMapping("/update")
	public String updateOwner(
			@Valid 
			@ModelAttribute 
			Owner owner, 
			BindingResult result, 
			
		
			
			Model model) {
		
		if (result.hasErrors()) {
			return "owner_update";
		}
		
		
		
		ownerService.updateOwner(owner);
		return "redirect:/owners/";
	}
	
	@GetMapping("/delete")
	public String deleteOwner(@RequestParam("id") Integer id, Model model, Authentication auth) {
		List<Insurance> insurances=ownerService.getOwnerById(id).getInsurances();
		if (insurances.isEmpty()) {
			ownerService.deleteOwner(id);
		}else {
			StringBuilder insurancesText=new StringBuilder();
			for (Insurance i:insurances) {
				insurancesText.append(i.getRegistrationNumber()).append(" ");
			}
			model.addAttribute("error","Vartotojas turi draudimo sutarčių iš pradžių reiktų panaikinti jas."
					+ " Draudimos sutartys: "+insurancesText.toString());
			model.addAttribute("ownerId", id);
			return this.owners(model, auth);
		}
		return "redirect:/owners/";
	}
}
