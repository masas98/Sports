package lt.bit.draudimas.classes;

public class OwnersCount {
	private Integer id;
	
	private String username;
	
	private Long owners;
	
	

	public OwnersCount() {
		super();
	}

	public OwnersCount(Integer id, String username, Long owners) {
		super();
		this.id = id;
		this.username = username;
		this.owners = owners;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Long getOwners() {
		return owners;
	}

	public void setOwners(Long owners) {
		this.owners = owners;
	}

	@Override
	public String toString() {
		return id + " " + username + " " + owners ;
	}
	

	
}
