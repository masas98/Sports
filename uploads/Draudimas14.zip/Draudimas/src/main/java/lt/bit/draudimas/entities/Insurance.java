package lt.bit.draudimas.entities;

import java.util.Date ;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "insurances")
public class Insurance {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column
	private String mark;
	
	@Column
	private String model;
	
	@Column(name = "registration_number")
	private String registrationNumber;
	
	@Column
	private Date date;
	
	@Column(name = "valid_until")
	private Date validUntil;
	
	@ManyToOne
	@JoinColumn(name="owner_id")
	private Owner owner;
	
	public Insurance() {
		
	}

	public Insurance(String mark, String model, String registrationNumber, Date date, Date validUntil, Owner owner) {
		super();
		this.mark = mark;
		this.model = model;
		this.registrationNumber = registrationNumber;
		this.date = date;
		this.validUntil = validUntil;
		this.owner = owner;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMark() {
		return mark;
	}

	public void setMark(String mark) {
		this.mark = mark;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getValidUntil() {
		return validUntil;
	}

	public void setValidUntil(Date validUntil) {
		this.validUntil = validUntil;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}
	
	

}
