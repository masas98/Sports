package lt.bit.draudimas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lt.bit.draudimas.services.UserService;

@Controller
@RequestMapping("/users")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@GetMapping("/")
	public String ownersCount(Model model) {
		//model.addAttribute("users", userService.countOwners());
		model.addAttribute("users", userService.countOwnersI());
		
		return "ownerscount";
	}
}
