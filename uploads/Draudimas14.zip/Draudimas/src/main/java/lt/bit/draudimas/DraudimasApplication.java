package lt.bit.draudimas;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import lt.bit.draudimas.services.StorageService;

@SpringBootApplication
public class DraudimasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DraudimasApplication.class, args);
	}
	
	@Bean
	CommandLineRunner init(StorageService storageService) {
		return (args) -> {
				storageService.init();
			};
	}
	

}

