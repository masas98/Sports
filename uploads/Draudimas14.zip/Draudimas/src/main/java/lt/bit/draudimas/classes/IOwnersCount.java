package lt.bit.draudimas.classes;

public interface IOwnersCount {
     Integer getId();
	 String getUsername();
	 Long getOwners();
}
