package lt.bit.draudimas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DraudimasApplicationTests {

	@Test
	void contextLoads() {
	}

}
